export { default } from "./ResultCard";
export * from "./ResultCard";
