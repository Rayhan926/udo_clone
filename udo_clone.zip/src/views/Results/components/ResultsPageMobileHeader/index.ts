export { default } from "./ResultsPageMobileHeader";
export * from "./ResultsPageMobileHeader";
