import Results from "@views/Results";
import React from "react";

const ResultsPage = () => {
  return <Results />;
};

export default ResultsPage;
