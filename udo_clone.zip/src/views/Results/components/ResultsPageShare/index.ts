export { default } from "./ResultsPageShare";
export * from "./ResultsPageShare";
