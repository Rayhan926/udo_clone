export { default } from "./SearchSuggestionAndUseMyLocation";
export * from "./SearchSuggestionAndUseMyLocation";
