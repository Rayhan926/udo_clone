import Privacy from "@views/Privacy";
import React from "react";

const PrivacyPage = () => {
  return <Privacy />;
};

export default PrivacyPage;
