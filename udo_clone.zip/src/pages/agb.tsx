import Agb from "@views/Agb";
import React from "react";

const AgbPage = () => {
  return <Agb />;
};

export default AgbPage;
