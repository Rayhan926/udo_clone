export { default } from "./PrivacyPolicyLayout";
export * from "./PrivacyPolicyLayout";
