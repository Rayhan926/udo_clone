export { default } from "./WeatherComponent";
export * from "./WeatherComponent";
