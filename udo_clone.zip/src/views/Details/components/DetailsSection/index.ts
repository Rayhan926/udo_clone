export { default } from "./DetailsSection";
export * from "./DetailsSection";
