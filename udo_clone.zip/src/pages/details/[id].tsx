import Details from "@views/Details";
import React from "react";

const SingleDetailsPage = () => {
  return <Details />;
};

export default SingleDetailsPage;
