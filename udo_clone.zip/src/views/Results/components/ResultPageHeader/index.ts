export { default } from "./ResultPageHeader";
export * from "./ResultPageHeader";
