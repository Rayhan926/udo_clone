import Contacts from "@views/Contacts";
import React from "react";

const ContactsPage = () => {
  return <Contacts />;
};

export default ContactsPage;
