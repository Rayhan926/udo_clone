export { default } from "./MobileSearchInput";
export * from "./MobileSearchInput";
