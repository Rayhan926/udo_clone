import Impressum from "@views/Impressum";
import React from "react";

const ImpressumPage = () => {
  return <Impressum />;
};

export default ImpressumPage;
