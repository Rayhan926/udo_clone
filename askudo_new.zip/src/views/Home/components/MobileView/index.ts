export { default } from "./MobileView";
export * from "./MobileView";
